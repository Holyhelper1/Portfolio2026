
import { ExternalLink, FolderGit2, Lock } from 'lucide-react';
import { useLanguage } from '../../../i18n';
import styles from './Projects.module.css';

export function Projects() {
  const { t, locale } = useLanguage();

  const projects = [
    {
      id: 'ireserve',
      title: t.projects.iReserve.title,
      description: t.projects.iReserve.description,
      tech: t.projects.iReserve.tech,
      accent: styles.cardAccent1,
      badge: 'React SPA',
      image: '/projects/ireserve.png',
      demoUrl: 'http://212.60.21.70/',
      codeUrl: 'https://github.com/Holyhelper1/iReserve',
      hasDemo: true,
      hasCode: true,
    },
    {
      id: 'nocodetesting',
      title: t.projects.noCodeTesting.title,
      subtitle: t.projects.noCodeTesting.subtitle,
      description: t.projects.noCodeTesting.description,
      tech: t.projects.noCodeTesting.tech,
      accent: styles.cardAccent2,
      badge: locale === 'ru' ? 'Коммерческий' : 'Commercial',
      image: '/projects/nocode.png',
      isPrivate: true,
    },
    {
      id: 'portfolio',
      title: t.projects.portfolio.title,
      description: t.projects.portfolio.description,
      tech: t.projects.portfolio.tech,
      accent: styles.cardAccent3,
      badge: locale === 'ru' ? 'Пет-проект' : 'Pet Project',
      image: '/projects/portfolio.png',
      demoUrl: 'https://holyhelper1.github.io/Portfolio/',
      codeUrl: 'https://github.com/Holyhelper1/Portfolio',
      hasDemo: true,
      hasCode: true,
    },
  ];

  const techToArray = (techStr: string) => techStr.split(',').map((t) => t.trim());

  return (
    <section className={styles.projects} id="projects">
      <h2 className={styles.sectionTitle}>{t.projects.title}</h2>
      <p className={styles.sectionSubtitle}>{t.projects.subtitle}</p>

      <div className={styles.grid}>
        {projects.map((project) => (
          <article
            key={project.id}
            className={`${styles.card} ${project.accent} ${
              project.id === 'portfolio' ? styles.cardFullWidth : ''
            }`}
          >
            <div className={styles.cardImage}>
              <img
                src={project.image}
                alt={project.title}
                loading="lazy"
              />
              <div className={styles.cardImageOverlay} />
              <span className={styles.cardBadge}>{project.badge}</span>
            </div>

            <div className={styles.cardBody}>
              <h3 className={styles.cardTitle}>{project.title}</h3>
              {project.subtitle && (
                <p className={styles.cardSubtitle}>{project.subtitle}</p>
              )}
              <p className={styles.cardDescription}>{project.description}</p>

              <div className={styles.cardTech}>
                {techToArray(project.tech).map((tech) => (
                  <span key={tech} className={styles.techTag}>
                    {tech}
                  </span>
                ))}
              </div>

              <div className={styles.cardActions}>
                {project.hasDemo && project.demoUrl && (
                  <a
                    href={project.demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${styles.cardLink} ${styles.cardLinkPrimary}`}
                  >
                    <ExternalLink size={14} /> {t.projects.iReserve.demo}
                  </a>
                )}
                {project.hasCode && project.codeUrl && (
                  <a
                    href={project.codeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`${styles.cardLink} ${styles.cardLinkSecondary}`}
                  >
                    <FolderGit2 size={14} /> {t.projects.iReserve.code}
                  </a>
                )}
                {project.isPrivate && (
                  <span className={styles.privateBadge}>
                    <Lock size={14} /> {t.projects.noCodeTesting.private}
                  </span>
                )}
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
